package Main;

import java.util.ArrayList;
import java.util.Scanner;

import Book.Book;
import Users.Admin;
import Users.Librarian;
import Users.Regular;
import Users.Student;
import Users.User;
import Users.userType;
import library.MunicipalLibrary;
import library.NationalLibrary;
import library.schoolLibrary;

public class main {

	public static void main(String[] args) {
		boolean flag1 = false, flag2 = false;
		String choice;
		boolean userFound = false;
		ArrayList<User> userlist = new ArrayList<>();
		ArrayList<Book> booksList = new ArrayList<>();
		Scanner input = new Scanner(System.in);
		String username;
		String password;
		Admin admin = new Admin("Admin", "Admin123", "Mostafa", "shalabox@gmail.com");
		Librarian liberarian = new Librarian("Liberarian", "Liberarian123", "Mahmoud", "sobh@gamil.com");
		Student student = new Student("Student", "Student123", "ahmed", "ahmed@gmail.com");
		Regular regular = new Regular("Regular", "Regular123", "Mohamed", "mohamed@gamil.com", true, true);
		// Regular regular= new
		// Regular("Regular","Regular123","Mohamed","mohamed@gamil.com", true, "Cairo");
		schoolLibrary schoollibrary = new schoolLibrary("sis");
		MunicipalLibrary municipallibrary = new MunicipalLibrary("Cairo", "Cairo");
		NationalLibrary nationallibrary = new NationalLibrary("Egypt");
		ArrayList<String> authors = new ArrayList<>();
		authors.add("William Shakespeare");
		Book book1 = new Book("The Merchant of Venice", authors, "9780198321521", 12, true, 7);
		authors.clear();
		authors.add("William Shakespeare");
		Book book2 = new Book("To Kill a Mockingbird", authors, "9780812416800", 16, true, 14);
		authors.clear();
		authors.add("Emily Brontë");
		Book book3 = new Book("The Wuthering Heights", authors, "9780312096892", 4, true, 30);
		authors.clear();
		schoollibrary.addUser(admin, userlist);
		schoollibrary.addUser(student, userlist);
		schoollibrary.addUser(liberarian, userlist);
		schoollibrary.addBook(book1, booksList);
		schoollibrary.addBook(book2, booksList);
		schoollibrary.addBook(book3, booksList);
		// nationallibrary.addUser(admin, userlist);
		nationallibrary.addUser(regular, userlist);
		nationallibrary.addBook(book1, booksList);
		nationallibrary.addBook(book2, booksList);
		nationallibrary.addBook(book3, booksList);
		// municipallibrary.addUser(admin, userlist);
		municipallibrary.addBook(book1, booksList);
		municipallibrary.addBook(book2, booksList);
		municipallibrary.addBook(book3, booksList);
		System.out.println("---------------Welcome to our online library---------------");
		System.out.println("-----------------------------------------------------------");
		// login
		System.out.println("Please login to use the system.");
		System.out.print("Enter username: ");
		username = input.nextLine();
		for (int i = 0; i < userlist.size(); i++) {
			User u = userlist.get(i);
			if (u.getUsername().equals(username)) {
				userFound = true;
				System.out.print("Enter password: ");
				password = input.nextLine();
				if (u.authenticate(password)) {
					String usertype = u.getUser_type().toString();
					System.out.println("Hello " + u.getName() + ", you logged in successfully as a(an) " + usertype);
					switch (usertype) {
					case ("Admin"):
						System.out.println("Choose library to enter");
						System.out.println("1-Scool library");
						System.out.println("2-municipal library");
						System.out.println("3-nationallibrary");
						int a = input.nextInt();
						switch (a) {
						case 1:
							System.out.println(
									"welcome in the school library" + '\n' + "please choose what would you like to do");
							System.out.println("1-add a user");
							System.out.println("2-add a book");
							System.out.println("3-remove a user");
							System.out.println("4-restrict a user");
							System.out.println("5-remove a book");
							System.out.println("6-search for a book");
							System.out.println("7-library statistics");
							int a2 = input.nextInt();
							switch (a2) {

							case 1:
								System.out.println("please enter the user information");
								System.out.println("---------------------------------");
								System.out.print("username: ");
								String userName = input.nextLine();
								System.out.println();
								System.out.print("password ");
								String passWord = input.next();
								System.out.println();
								System.out.print("name: ");
								String name = input.next();
								System.out.println();
								System.out.print("email: ");
								String Email = input.next();
								System.out.println();
								String type = input.next();
								if (type.equals("STUDENT")) {
									Student s = new Student(userName, passWord, name, Email);
									if (schoollibrary.addUser(s, userlist)) {
										System.out.println("user added successfully");
									}
								} else if (type.equals("ADMIN")) {
									Admin s = new Admin(userName, passWord, name, Email);
									if (schoollibrary.addUser(s, userlist)) {
										System.out.println("user added successfully");
									}
								} else if (type.equals("LIBERARIAN")) {
									Librarian s = new Librarian(userName, passWord, name, Email);
									if (schoollibrary.addUser(s, userlist)) {
										System.out.println("user was added successfully");
									}

								} else {
									System.out.print("please enter a valid type for the user");
								}
								break;
							case 2:
								System.out.println("please enter the book information");
								System.out.println("---------------------------------");
								System.out.print("Title: ");
								String Title = input.next();
								System.out.println();
								System.out.print("auothers: ");
								String auotherName = input.next();
								System.out.println();
								System.out.print("ISBN: ");
								String isbn = input.next();
								System.out.println();
								System.out.print("no. of copies: ");
								int noOfcopies = input.nextInt();
								System.out.println();
								System.out.print("availability: ");
								boolean Availability = input.nextBoolean();
								System.out.println();
								System.out.print("loan period: ");
								int loanPeriod = input.nextInt();
								System.out.println();
								authors.add(auotherName);
								Book b = new Book(Title, authors, isbn, noOfcopies, Availability, loanPeriod);
								if (schoollibrary.addBook(b, booksList)) {
									System.out.println("Book was added successfully");
								} else {
									System.out.println("Book adding failed");

								}
								break;
							case 3:
								System.out.print("please enter the username:");
								String r = input.next();
								schoollibrary.removeUser(r, userlist);
								System.out.println("user was removed successfully");
								break;
							case 4:
								System.out.print("please enter the username:");
								String res = input.next();
								schoollibrary.restrictUser(res);
								System.out.println(res + " was restricted successfully");
								break;
							case 5:
								System.out.print("please enter the book's ISBN:");
								String Isbn = input.next();
								for (int i2 = 0; i < booksList.size(); i++) {
									if (Isbn.equals(booksList.get(i2).getISBN())) {
										String tiTle = booksList.get(i2).getTitle();
										schoollibrary.removeBook(Isbn, booksList);
										System.out.println(tiTle + " was removed successfully");
									}
								}
								break;
							case 6:
								System.out.println("please enter the book's title:");
								String bTitlle = input.next();
								int sb = schoollibrary.searchBook(bTitlle);
								if (sb == -1) {
									System.out.println("book is not found");
								} else {
									System.out.println("index of the book is " + sb);
								}
								break;
							case 7:
								schoollibrary.stat();
								break;
							default:
								System.out.println("please choose a number from the list");

							}
						case 2:
							System.out.println("welcome in the municipal library" + '\n'
									+ "please choose what would you like to do");
							System.out.println("1-add a user");
							System.out.println("2-add a book");
							System.out.println("3-remove a user");
							System.out.println("4-restrict a user");
							System.out.println("5-remove a book");
							System.out.println("6-search for a book");
							System.out.println("7-library statistics");
							int a3 = input.nextInt();
							switch (a3) {

							case 1:
								System.out.println("please enter the user information");
								System.out.println("---------------------------------");
								System.out.print("username: ");
								String userName = input.nextLine();
								System.out.println();
								System.out.print("password ");
								String passWord = input.next();
								System.out.println();
								System.out.print("name: ");
								String name = input.next();
								System.out.println();
								System.out.print("email: ");
								String Email = input.next();
								System.out.println();
								String type = input.next();
								if (type.equals("STUDENT")) {
									Student s = new Student(userName, passWord, name, Email);
									if (municipallibrary.addUser(s, userlist)) {
										System.out.println("user added successfully");
									}
								} else if (type.equals("ADMIN")) {
									Admin s = new Admin(userName, passWord, name, Email);
									if (municipallibrary.addUser(s, userlist)) {
										System.out.println("user added successfully");
									}
								} else if (type.equals("LIBERARIAN")) {
									Librarian s = new Librarian(userName, passWord, name, Email);
									if (municipallibrary.addUser(s, userlist)) {
										System.out.println("user was added successfully");
									}

								} else {
									System.out.print("please enter a valid type for the user");
								}
								break;
							case 2:
								System.out.println("please enter the book information");
								System.out.println("---------------------------------");
								System.out.print("Title: ");
								String Title = input.next();
								System.out.println();
								System.out.print("auothers: ");
								String auotherName = input.next();
								System.out.println();
								System.out.print("ISBN: ");
								String isbn = input.next();
								System.out.println();
								System.out.print("no. of copies: ");
								int noOfcopies = input.nextInt();
								System.out.println();
								System.out.print("availability: ");
								boolean Availability = input.nextBoolean();
								System.out.println();
								System.out.print("loan period: ");
								int loanPeriod = input.nextInt();
								System.out.println();
								authors.add(auotherName);
								Book b = new Book(Title, authors, isbn, noOfcopies, Availability, loanPeriod);
								if (municipallibrary.addBook(b, booksList)) {
									System.out.println("Book was added successfully");
								} else {
									System.out.println("Book adding failed");

								}
								break;
							case 3:
								System.out.print("please enter the username:");
								String r = input.next();
								municipallibrary.removeUser(r, userlist);
								System.out.println("user was removed successfully");
								break;
							case 4:
								System.out.print("please enter the username:");
								String res = input.next();
								municipallibrary.restrictUser(res);
								System.out.println(res + " was restricted successfully");
								break;
							case 5:
								System.out.print("please enter the book's ISBN:");
								String Isbn = input.next();
								for (int i2 = 0; i < booksList.size(); i++) {
									if (Isbn.equals(booksList.get(i2).getISBN())) {
										String tiTle = booksList.get(i2).getTitle();
										municipallibrary.removeBook(Isbn, booksList);
										System.out.println(tiTle + " was removed successfully");
									}
								}
								break;
							case 6:
								System.out.println("please enter the book's title:");
								String bTitlle = input.next();
								int sb = municipallibrary.searchBook(bTitlle);
								if (sb == -1) {
									System.out.println("book is not found");
								} else {
									System.out.println("index of the book is " + sb);
								}
								break;
							case 7:
								municipallibrary.stat();
								break;
							default:
								System.out.println("please choose a number from the list");

							}
						case 3:
							System.out.println("welcome in the national library" + '\n'
									+ "please choose what would you like to do");
							System.out.println("1-add a user");
							System.out.println("2-add a book");
							System.out.println("3-remove a user");
							System.out.println("4-restrict a user");
							System.out.println("5-remove a book");
							System.out.println("6-search for a book");
							System.out.println("7-library statistics");
							int a4 = input.nextInt();
							switch (a4) {

							case 1:
								System.out.println("please enter the user information");
								System.out.println("---------------------------------");
								System.out.print("username: ");
								String userName = input.nextLine();
								System.out.println();
								System.out.print("password ");
								String passWord = input.next();
								System.out.println();
								System.out.print("name: ");
								String name = input.next();
								System.out.println();
								System.out.print("email: ");
								String Email = input.next();
								System.out.println();
								String type = input.next();
								if (type.equals("STUDENT")) {
									Student s = new Student(userName, passWord, name, Email);
									if (schoollibrary.addUser(s, userlist)) {
										System.out.println("user added successfully");
									}
								} else if (type.equals("ADMIN")) {
									Admin s = new Admin(userName, passWord, name, Email);
									if (schoollibrary.addUser(s, userlist)) {
										System.out.println("user added successfully");
									}
								} else if (type.equals("LIBERARIAN")) {
									Librarian s = new Librarian(userName, passWord, name, Email);
									if (schoollibrary.addUser(s, userlist)) {
										System.out.println("user was added successfully");
									}

								} else {
									System.out.print("please enter a valid type for the user");
								}
								break;
							case 2:
								System.out.println("please enter the book information");
								System.out.println("---------------------------------");
								System.out.print("Title: ");
								String Title = input.next();
								System.out.println();
								System.out.print("auothers: ");
								String auotherName = input.next();
								System.out.println();
								System.out.print("ISBN: ");
								String isbn = input.next();
								System.out.println();
								System.out.print("no. of copies: ");
								int noOfcopies = input.nextInt();
								System.out.println();
								System.out.print("availability: ");
								boolean Availability = input.nextBoolean();
								System.out.println();
								System.out.print("loan period: ");
								int loanPeriod = input.nextInt();
								System.out.println();
								authors.add(auotherName);
								Book b = new Book(Title, authors, isbn, noOfcopies, Availability, loanPeriod);
								if (nationallibrary.addBook(b, booksList)) {
									System.out.println("Book was added successfully");
								} else {
									System.out.println("Book adding failed");

								}
								break;
							case 3:
								System.out.print("please enter the username:");
								String r = input.next();
								nationallibrary.removeUser(r, userlist);
								System.out.println("user was removed successfully");
								break;
							case 4:
								System.out.print("please enter the username:");
								String res = input.next();
								nationallibrary.restrictUser(res);
								System.out.println(res + " was restricted successfully");
								break;
							case 5:
								System.out.print("please enter the book's ISBN:");
								String Isbn = input.next();
								for (int i2 = 0; i < booksList.size(); i++) {
									if (Isbn.equals(booksList.get(i2).getISBN())) {
										String tiTle = booksList.get(i2).getTitle();
										nationallibrary.removeBook(Isbn, booksList);
										System.out.println(tiTle + " was removed successfully");
									}
								}
								break;
							case 6:
								System.out.println("please enter the book's title:");
								String bTitlle = input.next();
								int sb = nationallibrary.searchBook(bTitlle);
								if (sb == -1) {
									System.out.println("book is not found");
								} else {
									System.out.println("index of the book is " + sb);
								}
								break;
							case 7:
								nationallibrary.stat();
								break;
							default:
								System.out.println("please choose a number from the list");

							}

						}
					}

				} else {
					System.out.print("invalid password");
				}
			}
		}

	}
}
