package Users;

import java.util.UUID;

public class Regular extends User {
	private boolean adult;
	private boolean creditCard;
	private String area;

	public Regular(String username, String password, String name, String email, boolean creditCard, boolean adult) {
		super(username, password, name, email, userType.REGULAR);
		this.creditCard = creditCard;
		this.adult = adult;

	}

	public Regular(String username, String password, String name, UUID ID, String email, boolean creditCard,
			String area) {
		super(username, password, name, email, userType.REGULAR);
		this.creditCard = creditCard;
		this.area = area;

	}

	public boolean isAdult() {
		return adult;
	}

	public boolean isCreditCard() {
		return creditCard;
	}

	public String getArea() {
		return area;
	}

}
