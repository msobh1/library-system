package Users;

import java.util.UUID;

public class Student extends User {
	public Student(String username, String password, String name, String email) {
		super(username, password, name, email, userType.STUDENT);

	}

}
