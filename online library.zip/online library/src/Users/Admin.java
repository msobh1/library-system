package Users;

import java.util.UUID;

public class Admin extends User {
	public Admin(String username, String password, String name, String email) {
		super(username, password, name, email, userType.Admin);

	}

}
