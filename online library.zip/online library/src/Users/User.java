package Users;

import java.util.ArrayList;
import java.util.UUID;

import Book.Book;

public class User implements Comparable {
	private String username;
	private String password;
	private String name;
	private UUID ID;
	private ArrayList<Book> borrowedBooks;
	private int dueAmount;
	private String email;
	private userType user_type;
	private int borrowingTimes;

	public User(String username, String password, String name, String email, userType user_type) {
		this.username = username;
		this.password = password;
		this.name = name;
		this.ID = UUID.randomUUID();
		this.email = email;
		this.borrowedBooks = new ArrayList<>();
		this.dueAmount = 0;
		this.user_type = user_type;
		this.borrowingTimes = 0;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getName() {
		return name;
	}

	public UUID getID() {
		return ID;
	}

	public ArrayList<Book> getBorrowedBooks() {
		return borrowedBooks;
	}

	public String getEmail() {
		return email;
	}

	public int getDueAmount() {
		return dueAmount;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setID(UUID iD) {
		ID = iD;
	}

	public void setBorrowedBooks(ArrayList<Book> borrowedBooks) {
		this.borrowedBooks = borrowedBooks;
	}

	public void setDueAmount(int dueAmount) {
		this.dueAmount = dueAmount;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public userType getUser_type() {
		return user_type;
	}

	public boolean authenticate(String myPassword) {
		return password.equals(myPassword);
	}

	public void setBorrowingTimes(int borrowingTimes) {
		this.borrowingTimes = borrowingTimes;
	}

	public int getBorrowingTimes() {
		return borrowingTimes;
	}

	@Override
	public int compareTo(Object o) {
		User x = (User) o;
		if (this.borrowingTimes > x.borrowingTimes) {
			return 1;
		} else if (this.borrowingTimes < x.borrowingTimes) {
			return -1;
		} else {
			return 0;
		}
	}

	public String toString() {
		return "Name: " + this.name + '\n' + "ID; " + this.ID + '\n' + "Borrowing times: " + this.borrowingTimes;
	}

}
