package Users;

import java.util.UUID;

public class Librarian extends User {
	public Librarian(String username, String password, String name, String email) {
		super(username, password, name, email, userType.Librarian);

	}

}