package Users;

public enum userType {
	Admin, Librarian, STUDENT, REGULAR

}