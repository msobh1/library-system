package Book;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import Users.User;

public class Book implements Comparable {
	private String title;
	ArrayList<String> authors;
	private String ISBN;
	private int physicalCopies;
	private int borrowedCopies;
	private int totalCopies;
	private boolean availability;
	private int loanPeriod;
	private HashMap<User, LocalDate> borrowers;
	private int borrowed;

	public Book(String title, ArrayList<String> authors, String ISBN, int totalCopies, boolean availability,
			int loanPeriod) {
		this.title = title;
		this.authors = authors;
		this.ISBN = ISBN;
		this.physicalCopies = totalCopies;
		this.borrowedCopies = 0;
		this.totalCopies = totalCopies;
		this.availability = availability;
		this.loanPeriod = loanPeriod;
		this.borrowers = new HashMap<>();
		this.borrowed = 0;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String ISBN) {
		this.ISBN = ISBN;
	}

	public String getTitle() {
		return title;
	}

	public int getPhysicalCopies() {
		return physicalCopies;
	}

	public void setPhysicalCopies(int physicalCopies) {
		this.physicalCopies = physicalCopies;
	}

	public int getBorrowedCopies() {
		return borrowedCopies;
	}

	public void setBorrowedCopies(int borrowedCopies) {
		this.borrowedCopies = borrowedCopies;
	}

	public int getTotalCopies() {
		return totalCopies;
	}

	public boolean isAvailability() {
		return availability;
	}

	public int getLoanPeriod() {
		return loanPeriod;
	}

	public HashMap<User, LocalDate> getBorrowers() {
		return borrowers;
	}

	public ArrayList<String> getAuthors() {
		return authors;
	}

	public int getBorrowed() {
		return borrowed;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setAuthors(ArrayList<String> authors) {
		this.authors = authors;
	}

	public void setTotalCopies(int totalCopies) {
		this.totalCopies = totalCopies;
	}

	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

	public void setLoanPeriod(int loanPeriod) {
		this.loanPeriod = loanPeriod;
	}

	public void setBorrowers(HashMap<User, LocalDate> borrowers) {
		this.borrowers = borrowers;
	}

	public void setBorrowed(int borrowed) {
		this.borrowed = borrowed;
	}

	@Override
	public int compareTo(Object o) {
		Book b = (Book) o;
		if (this.borrowed > b.borrowed) {
			return 1;
		} else if (this.borrowed < b.borrowed) {
			return -1;
		} else {
			return 0;
		}
	}
	public String toString() {
		return "Title: "+this.title;
	}

}
