package library;

import java.util.ArrayList;

import Book.Book;
import Users.User;
import Users.userType;

public class schoolLibrary extends Library {
	public schoolLibrary(String name) {
		super(name, LibraryType.SCHOOL);
		getAllowedUsers().add(userType.STUDENT);
		getAllowedUsers().add(userType.Admin);
		getAllowedUsers().add(userType.Librarian);
	}

	@Override
	public boolean addUser(User x,ArrayList<User> users) {
		if (x.getUser_type().equals(userType.STUDENT) || x.getUser_type().equals(userType.Admin)
				|| x.getUser_type().equals(userType.Librarian)) {
			super.addUser(x, users);
		}return false;
	}

	@Override
	public boolean borrowBook(User x, Book y) {
		if (x.getUser_type().equals(userType.STUDENT)) {
			return super.borrowBook(x, y);
		}
		return false;
	}

}
