package library;

import java.util.ArrayList;

import Book.Book;
import Users.Regular;
import Users.User;
import Users.userType;

public class NationalLibrary extends Library {
	public NationalLibrary(String name) {
		super(name, LibraryType.NATIONAL);
		getAllowedUsers().add(userType.REGULAR);
	}

	@Override
	public boolean addUser(User x,ArrayList<User> users) {
		Regular r = (Regular) x;
		if (r.isAdult()||x.getUser_type().equals(userType.Admin)) {
			super.addUser(x, users);
		}return false;
	}

	@Override
	public boolean borrowBook(User x, Book y) {
		Regular r = (Regular) x;
		if (r.isCreditCard()) {
			return super.borrowBook(x, y);
		}
		return false;
	}

}
