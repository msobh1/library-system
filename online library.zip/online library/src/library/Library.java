package library;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import Book.Book;
import Users.User;
import Users.userType;

public class Library {
	private String name;
	private LibraryType type;
	private ArrayList<userType> allowedUsers;
	private ArrayList<User> registerdUsers;
	private ArrayList<User> restrictedUser;
	private ArrayList<Book> books;
	private int loanPeriod;
	private int graceperiod;
	private int noOfExtends;
	private ArrayList<Book> loans;

	public Library() {
		name = null;
		type = null;
		allowedUsers = new ArrayList<>();
		registerdUsers = new ArrayList<>();
		restrictedUser = new ArrayList<>();
		books = new ArrayList<>();
		loanPeriod = 0;
		graceperiod = 0;
		noOfExtends = 0;
		loans = new ArrayList<>();
	}

	public Library(String name) {
		this.name = name;
		type = null;
		allowedUsers = new ArrayList<>();
		registerdUsers = new ArrayList<>();
		restrictedUser = new ArrayList<>();
		books = new ArrayList<>();
		loanPeriod = 0;
		graceperiod = 0;
		noOfExtends = 0;
		loans = new ArrayList<>();
	}

	public Library(String name, LibraryType type) {
		this.name = name;
		this.type = type;
		this.allowedUsers = new ArrayList<>();
		registerdUsers = new ArrayList<>();
		restrictedUser = new ArrayList<>();
		books = new ArrayList<>();
		loanPeriod = 0;
		graceperiod = 0;
		noOfExtends = 0;
		loans = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public LibraryType getType() {
		return type;
	}

	public ArrayList<userType> getAllowedUsers() {
		return allowedUsers;
	}

	public ArrayList<User> getRegisterdUsers() {
		return registerdUsers;
	}

	public ArrayList<User> getRestrictedUser() {
		return restrictedUser;
	}

	public ArrayList<Book> getBooks() {
		return books;
	}

	public int getLoanPeriod() {
		return loanPeriod;
	}

	public int getGraceperiod() {
		return graceperiod;
	}

	public int getNoOfExtends() {
		return noOfExtends;
	}

	public ArrayList<Book> getLoans() {
		return loans;
	}

	public void setLoanPeriod(int loanPeriod) {
		this.loanPeriod = loanPeriod;
	}

	public void setGraceperiod(int graceperiod) {
		this.graceperiod = graceperiod;
	}

	public void setNoOfExtends(int noOfExtends) {
		this.noOfExtends = noOfExtends;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setType(LibraryType type) {
		this.type = type;
	}

	public void setAllowedUsers(ArrayList<userType> allowedUsers) {
		this.allowedUsers = allowedUsers;
	}

	public void setRegisterdUsers(ArrayList<User> registerdUsers) {
		this.registerdUsers = registerdUsers;
	}

	public void setRestrictedUser(ArrayList<User> restrictedUser) {
		this.restrictedUser = restrictedUser;
	}

	public void setBooks(ArrayList<Book> books) {
		this.books = books;
	}

	public void setLoans(ArrayList<Book> loans) {
		this.loans = loans;
	}

	public boolean addUser(User x, ArrayList<User> users) {
		for (int i = 0; i < registerdUsers.size(); i++) {
			if (x.equals(registerdUsers.get(i))) {
				return false;
			}
		}
		registerdUsers.add(x);
		users.add(x);
		return true;
	}

	public boolean addBook(Book x, ArrayList<Book> allBooks) {
		for (int i = 0; i < books.size(); i++) {
			if (x.equals(books.get(i))) {
				return false;
			}
		}
		books.add(x);
		allBooks.add(x);
		return true;

	}

	public boolean removeUser(String x, ArrayList<User> users) {
		for (int i = 0; i < registerdUsers.size(); i++) {
			if (x.equals(registerdUsers.get(i).getUsername())) {
				User u = registerdUsers.get(i);
				for (int j = 0; j < u.getBorrowedBooks().size(); i++) {
					books.add(u.getBorrowedBooks().get(j));
				}
				u.getBorrowedBooks().clear();
				registerdUsers.remove(u);
				users.remove(u);
				return true;

			}
		}
		return false;
	}

	public void restrictUser(String x) {
		for (int i = 0; i < registerdUsers.size(); i++) {

			if (x.equals(registerdUsers.get(i).getUsername())) {
				User u = registerdUsers.get(i);
				restrictedUser.add(u);
			}
		}
	}

	public void removeBook(String x, ArrayList<Book> allBooks) {
		for (int i = 0; i < books.size(); i++) {
			if (x.equals(books.get(i).getISBN())) {
				Book b = books.get(i);
				books.remove(b);
				allBooks.remove(b);

			}
		}
	}

	public void policy(int lp, int gp, int extend) {
		this.loanPeriod = lp;
		this.graceperiod = gp;
		this.noOfExtends = extend;
	}

	public boolean search(Book x) {
		for (int i = 0; i < books.size(); i++) {
			if (x.getTitle().equals(books.get(i).getTitle())) {
				for (int j = 0; j < loans.size(); j++) {
					if (x.getTitle().equals(loans.get(j))) {
						return false;
					}
				}
				return true;

			}

		}
		return false;

	}

	public boolean check(User x) {
		boolean flag1 = true;
		boolean flag2 = true;
		for (int i = 0; i < restrictedUser.size(); i++) {
			if (x.equals(restrictedUser.get(i))) {
				flag1 = false;
			}
		}
		if (x.getDueAmount() > 0) {
			flag2 = false;
		}
		return flag1 || flag2;
	}

	public boolean borrowBook(User x, Book y) {
		if (check(x)) {
			if (search(y)) {
				x.getBorrowedBooks().add(y);
				loans.add(y);
				y.setBorrowed(y.getBorrowed() + 1);
				x.setBorrowingTimes(x.getBorrowingTimes() + 1);
				return true;
			}
			return false;
		}
		return false;
	}

	public void returnBook(User x, Book y) {
		x.getBorrowedBooks().remove(y);
		loans.remove(y);
		LocalDate d1 = y.getBorrowers().get(x);
		int z = y.getLoanPeriod();
		LocalDate d2 = d1.plusDays(z);
		LocalDate d3 = LocalDate.now();
		if (d3.isAfter(d2)) {
			x.setDueAmount(100);
		}
	}

	public int searchBook(String bookTitle) {
		for (int i = 0; i < books.size(); i++) {
			if (bookTitle.equals(books.get(i).getTitle())) {
				return i;
			}
		}
		return -1;
	}

	public PriorityQueue freqBooks() {
		PriorityQueue x = new PriorityQueue(books.size());
		for (int i = 0; i < books.size(); i++) {
			x.insert(books.get(i));
		}
		return x;

	}

	public PriorityQueue freqUsers() {
		PriorityQueue x = new PriorityQueue(registerdUsers.size());
		for (int i = 0; i < registerdUsers.size(); i++) {
			x.insert(registerdUsers.get(i));
		}
		return x;

	}

	public void stat() {
		PriorityQueue x = freqBooks();
		PriorityQueue y = freqUsers();
		System.out.print("Frequently borrowed books: ");
		for (int i = 0; i < 4; i++) {
			System.out.print(x.remove());
		}
		System.out.print("Frequently borrowing users: ");
		for (int i = 0; i < 4; i++) {
			System.out.print(y.remove());
		}
	}

}
