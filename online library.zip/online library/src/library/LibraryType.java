package library;

public enum LibraryType {
	SCHOOL, MUNICIPAL, NATIONAL
}
